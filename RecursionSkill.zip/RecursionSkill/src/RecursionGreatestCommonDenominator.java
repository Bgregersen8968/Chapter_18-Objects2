import java.util.Scanner;

public class RecursionGreatestCommonDenominator {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter two numbers to find the GCD:  ");
		double m = in.nextDouble();
		double n = in.nextDouble();
		gcd(m, n);
		System.out.print("The Greatest common denominator is : " + gcd(m, n));
	}

	public static double gcd(double m, double n) {
		if (m % n <= 0)
			return n;
		else
			return gcd(n, m % n);
	}
}
